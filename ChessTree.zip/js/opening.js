const OPENING_FILES = [
    "data/openings/alekhine-defense.json",
    "data/openings/bird-opening.json",
    "data/openings/caro-kann-defense.json",
    "data/openings/english-opening.json",
    "data/openings/evans-gambit.json",
    "data/openings/french-defense.json",
    "data/openings/italian-game.json",
    "data/openings/kings-gambit.json",
    "data/openings/nimzo-indian-defense.json",
    "data/openings/pirc-defense.json",
    "data/openings/queens-gambit.json",
    "data/openings/ruy-lopez.json",
    "data/openings/scandinavian-defense.json",
    "data/openings/sicilian-defense.json"
];

const OPENING_DETAILS_FILE = "data/openings/opening-details.json";
const EXPLORER_URL = "tree.html";

const PIECE_IMAGES = {
    P: "https://upload.wikimedia.org/wikipedia/commons/4/45/Chess_plt45.svg",
    N: "https://upload.wikimedia.org/wikipedia/commons/7/70/Chess_nlt45.svg",
    B: "https://upload.wikimedia.org/wikipedia/commons/b/b1/Chess_blt45.svg",
    R: "https://upload.wikimedia.org/wikipedia/commons/7/72/Chess_rlt45.svg",
    Q: "https://upload.wikimedia.org/wikipedia/commons/1/15/Chess_qlt45.svg",
    K: "https://upload.wikimedia.org/wikipedia/commons/4/42/Chess_klt45.svg",
    p: "https://upload.wikimedia.org/wikipedia/commons/c/c7/Chess_pdt45.svg",
    n: "https://upload.wikimedia.org/wikipedia/commons/e/ef/Chess_ndt45.svg",
    b: "https://upload.wikimedia.org/wikipedia/commons/9/98/Chess_bdt45.svg",
    r: "https://upload.wikimedia.org/wikipedia/commons/f/ff/Chess_rdt45.svg",
    q: "https://upload.wikimedia.org/wikipedia/commons/4/47/Chess_qdt45.svg",
    k: "https://upload.wikimedia.org/wikipedia/commons/f/f0/Chess_kdt45.svg"
};

const elements = {
    breadcrumbCurrent: document.getElementById("breadcrumbCurrent"),
    openingTitle: document.getElementById("openingTitle"),
    openingBadges: document.getElementById("openingBadges"),
    openingTagline: document.getElementById("openingTagline"),
    openingPreview: document.getElementById("openingPreview"),
    openingDescription: document.getElementById("openingDescription"),
    keyIdeasBlock: document.getElementById("keyIdeasBlock"),
    keyIdeasList: document.getElementById("keyIdeasList"),
    difficultyValue: document.getElementById("difficultyValue"),
    difficultyScale: document.getElementById("difficultyScale"),
    popularityScale: document.getElementById("popularityScale"),
    variationsValue: document.getElementById("variationsValue"),
    openExplorerButton: document.getElementById("openExplorerButton"),
    openMainLineButton: document.getElementById("openMainLineButton"),
    variationsList: document.getElementById("variationsList"),
    variationsEmpty: document.getElementById("variationsEmpty")
};

function slugify(value) {
    return String(value)
        .toLowerCase()
        .replace(/[^a-z0-9\s-]/g, "")
        .trim()
        .replace(/\s+/g, "-");
}

function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
}

function mapDifficultyLabel(level) {
    if (level <= 2) return "Beginner";
    if (level <= 4) return "Intermediate";
    return "Advanced";
}

function normalizeSide(value) {
    const normalized = String(value || "").trim().toLowerCase();
    if (normalized === "white" || normalized === "black") return normalized;
    return "";
}

function normalizeText(value, fallback = "") {
    const normalized = String(value || "").trim();
    return normalized || fallback;
}

function normalizeOpening(raw) {
    const name = normalizeText(raw.name);
    if (!name) return null;

    const id = normalizeText(raw.id, slugify(name));
    const difficultyRaw = Number.isFinite(Number(raw.difficultyLevel))
        ? Number(raw.difficultyLevel)
        : Number(raw.difficulty);
    const difficultyLevel = Number.isFinite(difficultyRaw)
        ? clamp(Math.round(difficultyRaw), 1, 5)
        : 3;
    const variationCount = Number.parseInt(raw.variationCount, 10);
    const popularity = Number.parseInt(raw.popularity, 10);

    return {
        id,
        name,
        side: normalizeSide(raw.side),
        style: normalizeText(raw.style),
        openingType: normalizeText(raw.openingType),
        tagline: normalizeText(raw.tagline),
        description: normalizeText(raw.description),
        difficultyLevel,
        difficultyLabel: normalizeText(raw.difficultyLabel, mapDifficultyLabel(difficultyLevel)),
        variationCount: Number.isFinite(variationCount) && variationCount > 0 ? variationCount : 0,
        popularity: Number.isFinite(popularity) ? clamp(popularity, 1, 5) : 3,
        fen: normalizeText(raw.fen)
    };
}

function normalizeVariation(raw) {
    const name = normalizeText(raw?.name);
    const moves = normalizeText(raw?.moves);
    const description = normalizeText(raw?.description);
    if (!name && !moves && !description) return null;

    const difficulty = normalizeText(raw?.difficulty, "Intermediate");
    return {
        id: normalizeText(raw?.id, slugify(name || moves)),
        name: name || "Variation",
        moves: moves || "Moves in progress.",
        description: description || "Description in progress.",
        difficulty
    };
}

function normalizeDetails(rawDetails) {
    const details = {};
    if (!rawDetails || typeof rawDetails !== "object") return details;

    Object.entries(rawDetails).forEach(([openingId, value]) => {
        const variations = Array.isArray(value?.variations)
            ? value.variations.map(normalizeVariation).filter(Boolean)
            : [];

        const keyIdeas = Array.isArray(value?.keyIdeas)
            ? value.keyIdeas
                .map((idea) => normalizeText(idea))
                .filter(Boolean)
                .slice(0, 3)
            : [];

        details[openingId] = {
            eco: normalizeEco(value?.eco),
            keyIdeas,
            mainLineMoves: normalizeText(value?.mainLineMoves),
            variations
        };
    });

    return details;
}

function normalizeEco(value) {
    const eco = normalizeText(value).toUpperCase();
    if (/^[A-E][0-9]{2}$/.test(eco)) return eco;
    return "";
}

async function loadJson(path) {
    try {
        const response = await fetch(path);
        if (!response.ok) return null;
        return await response.json();
    } catch (_error) {
        return null;
    }
}

async function loadOpenings() {
    const rawItems = await Promise.all(OPENING_FILES.map(loadJson));
    return rawItems
        .filter(Boolean)
        .map(normalizeOpening)
        .filter(Boolean)
        .sort((a, b) => a.name.localeCompare(b.name));
}

async function loadDetails() {
    const rawDetails = await loadJson(OPENING_DETAILS_FILE);
    return normalizeDetails(rawDetails);
}

function getRequestedOpeningId() {
    const params = new URLSearchParams(window.location.search);
    return normalizeText(params.get("id")).toLowerCase();
}

function findOpening(openings, requestedId) {
    if (!openings.length) return null;
    if (!requestedId) return openings[0];

    const direct = openings.find((item) => item.id.toLowerCase() === requestedId);
    if (direct) return direct;

    const bySlug = openings.find((item) => slugify(item.name) === requestedId);
    return bySlug || openings[0];
}

function createBadge(text, className = "") {
    const badge = document.createElement("span");
    badge.className = `badge${className ? ` ${className}` : ""}`;
    badge.textContent = text;
    return badge;
}

function createDotScale(total, filled) {
    const fragment = document.createDocumentFragment();
    for (let i = 0; i < total; i += 1) {
        const dot = document.createElement("span");
        dot.className = `dot${i < filled ? " filled" : ""}`;
        fragment.appendChild(dot);
    }
    return fragment;
}

function parseFEN(fen) {
    const boardPart = String(fen || "").split(" ")[0];
    const rows = boardPart.split("/");
    const matrix = [];

    for (let rowIndex = 0; rowIndex < 8; rowIndex += 1) {
        const row = [];
        const sourceRow = rows[rowIndex] || "";
        for (const char of sourceRow) {
            if (/\d/.test(char)) {
                const count = Number(char);
                for (let i = 0; i < count; i += 1) row.push(null);
            } else {
                row.push(char);
            }
        }
        while (row.length < 8) row.push(null);
        matrix.push(row.slice(0, 8));
    }

    return matrix;
}

function parseFenPieces(fen) {
    const matrix = parseFEN(fen);
    const pieceMap = new Map();

    matrix.forEach((row, rowIndex) => {
        row.forEach((pieceCode, colIndex) => {
            if (pieceCode) {
                pieceMap.set(`${rowIndex}-${colIndex}`, pieceCode);
            }
        });
    });

    return pieceMap;
}

function renderBoardPreview(fen) {
    if (!elements.openingPreview) return;

    elements.openingPreview.innerHTML = "";
    if (!fen) {
        const placeholder = document.createElement("div");
        placeholder.className = "preview-placeholder";
        placeholder.textContent = "Preview in progress.";
        elements.openingPreview.appendChild(placeholder);
        return;
    }

    const pieceMap = parseFenPieces(fen);
    for (let row = 0; row < 8; row += 1) {
        for (let col = 0; col < 8; col += 1) {
            const square = document.createElement("div");
            square.className = `board-square ${((row + col) % 2 === 0) ? "dark" : "light"}`;

            const pieceCode = pieceMap.get(`${row}-${col}`);
            if (pieceCode && PIECE_IMAGES[pieceCode]) {
                const image = document.createElement("img");
                image.className = "board-piece";
                image.src = PIECE_IMAGES[pieceCode];
                image.alt = "";
                image.loading = "lazy";
                square.appendChild(image);
            }

            elements.openingPreview.appendChild(square);
        }
    }
}

function mapLevelToCompactScale(level) {
    if (level <= 2) return 1;
    if (level <= 4) return 2;
    return 3;
}

function buildExplorerUrl(openingId, options = {}) {
    const params = new URLSearchParams();
    params.set("opening", openingId);

    if (options.variation) {
        params.set("variation", options.variation);
    }

    if (options.line) {
        params.set("line", options.line);
    }

    return `${EXPLORER_URL}?${params.toString()}`;
}

function renderHeader(opening, details) {
    if (elements.breadcrumbCurrent) {
        elements.breadcrumbCurrent.textContent = opening.name;
    }

    if (elements.openingTitle) {
        elements.openingTitle.textContent = opening.name;
    }

    if (elements.openingBadges) {
        elements.openingBadges.innerHTML = "";
        if (opening.side) {
            elements.openingBadges.appendChild(createBadge(opening.side === "white" ? "White" : "Black", "badge--side"));
        }
        elements.openingBadges.appendChild(createBadge(opening.difficultyLabel, "badge--difficulty"));
        if (details.eco) {
            elements.openingBadges.appendChild(createBadge(details.eco));
        }
        if (opening.style) {
            elements.openingBadges.appendChild(createBadge(opening.style));
        }
        if (opening.openingType) {
            elements.openingBadges.appendChild(createBadge(opening.openingType));
        }
    }

    if (elements.openingTagline) {
        if (opening.tagline) {
            elements.openingTagline.hidden = false;
            elements.openingTagline.textContent = opening.tagline;
        } else {
            elements.openingTagline.hidden = true;
            elements.openingTagline.textContent = "";
        }
    }
}

function renderDescription(opening, details) {
    if (elements.openingDescription) {
        elements.openingDescription.textContent = opening.description || "Description in progress.";
    }

    if (!elements.keyIdeasBlock || !elements.keyIdeasList) return;
    elements.keyIdeasList.innerHTML = "";

    if (!details.keyIdeas.length) {
        elements.keyIdeasBlock.hidden = true;
        return;
    }

    details.keyIdeas.forEach((idea) => {
        const li = document.createElement("li");
        li.textContent = idea;
        elements.keyIdeasList.appendChild(li);
    });

    elements.keyIdeasBlock.hidden = false;
}

function renderStats(opening, details) {
    if (elements.difficultyValue) {
        elements.difficultyValue.textContent = opening.difficultyLabel;
    }

    if (elements.difficultyScale) {
        elements.difficultyScale.innerHTML = "";
        elements.difficultyScale.appendChild(createDotScale(3, mapLevelToCompactScale(opening.difficultyLevel)));
    }

    if (elements.popularityScale) {
        elements.popularityScale.innerHTML = "";
        elements.popularityScale.appendChild(createDotScale(5, opening.popularity));
    }

    const variationCount = Math.max(opening.variationCount, details.variations.length);
    if (elements.variationsValue) {
        elements.variationsValue.textContent = String(variationCount);
    }
}

function renderActions(opening, details) {
    if (elements.openExplorerButton) {
        elements.openExplorerButton.onclick = () => {
            window.location.href = buildExplorerUrl(opening.id);
        };
    }

    if (!elements.openMainLineButton) return;

    if (!details.mainLineMoves) {
        elements.openMainLineButton.hidden = true;
        elements.openMainLineButton.onclick = null;
        return;
    }

    elements.openMainLineButton.hidden = false;
    elements.openMainLineButton.onclick = () => {
        window.location.href = buildExplorerUrl(opening.id, { line: "main" });
    };
}

function createVariationCard(opening, variation) {
    const card = document.createElement("article");
    card.className = "variation-card";

    const head = document.createElement("div");
    head.className = "variation-card__head";

    const title = document.createElement("h3");
    title.className = "variation-name";
    title.textContent = variation.name;

    const difficultyBadge = createBadge(variation.difficulty, "badge--difficulty");

    head.appendChild(title);
    head.appendChild(difficultyBadge);

    const moves = document.createElement("p");
    moves.className = "variation-moves";
    moves.textContent = variation.moves;

    const description = document.createElement("p");
    description.className = "variation-desc";
    description.textContent = variation.description;

    const footer = document.createElement("div");
    footer.className = "variation-card__footer";

    const openButton = document.createElement("button");
    openButton.type = "button";
    openButton.className = "variation-action";
    openButton.textContent = "Open in Explorer";
    openButton.addEventListener("click", () => {
        window.location.href = buildExplorerUrl(opening.id, { variation: variation.id });
    });

    footer.appendChild(openButton);
    card.appendChild(head);
    card.appendChild(moves);
    card.appendChild(description);
    card.appendChild(footer);

    return card;
}

function renderVariations(opening, details) {
    if (!elements.variationsList || !elements.variationsEmpty) return;

    elements.variationsList.innerHTML = "";
    if (!details.variations.length) {
        elements.variationsEmpty.hidden = false;
        return;
    }

    elements.variationsEmpty.hidden = true;
    details.variations.forEach((variation) => {
        elements.variationsList.appendChild(createVariationCard(opening, variation));
    });
}

function renderOpeningPage(opening, detailsMap) {
    const details = detailsMap[opening.id] || {
        eco: "",
        keyIdeas: [],
        mainLineMoves: "",
        variations: []
    };

    document.title = `${opening.name} - ChessTree`;
    renderHeader(opening, details);
    renderBoardPreview(opening.fen);
    renderDescription(opening, details);
    renderStats(opening, details);
    renderActions(opening, details);
    renderVariations(opening, details);
}

function renderUnavailable(message) {
    if (elements.breadcrumbCurrent) elements.breadcrumbCurrent.textContent = "Opening";
    if (elements.openingTitle) elements.openingTitle.textContent = "Opening";
    if (elements.openingBadges) elements.openingBadges.innerHTML = "";
    if (elements.openingTagline) elements.openingTagline.hidden = true;
    if (elements.openingDescription) elements.openingDescription.textContent = message;
    if (elements.keyIdeasBlock) elements.keyIdeasBlock.hidden = true;
    if (elements.variationsList) elements.variationsList.innerHTML = "";
    if (elements.variationsEmpty) {
        elements.variationsEmpty.hidden = false;
        elements.variationsEmpty.textContent = "Variations in progress.";
    }
    if (elements.openExplorerButton) elements.openExplorerButton.disabled = true;
    if (elements.openMainLineButton) elements.openMainLineButton.hidden = true;
    renderBoardPreview("");
}

async function init() {
    const [openings, detailsMap] = await Promise.all([loadOpenings(), loadDetails()]);
    if (!openings.length) {
        renderUnavailable("Unable to load opening data. Start a local server and reload this page.");
        return;
    }

    const requestedId = getRequestedOpeningId();
    const opening = findOpening(openings, requestedId);
    if (!opening) {
        renderUnavailable("Opening is unavailable.");
        return;
    }

    renderOpeningPage(opening, detailsMap);
}

init();
